<?php
  require 'inc/header.php';
?>


        <div class="row align-items-center">
            <div class="col-10 col-lg-4 col-xl-11">
                <h1>Location de matériel Roilles</h1>
                  <div>
                      <p>pour tous vos besoins de travaux ...</p>
                  </div>
            </div>
        </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->


    <!-- ##### Footer Area Start ##### -->
<?php require 'inc/footer.php'; ?>
